<?php if(count($medicines) > 0): ?>
<?php if(isset($medicines['data'])): ?>
<?php
$data = $medicines['data'];
?>
<?php else: ?>
<?php
$data = $medicines;
?>
<?php endif; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="bg-white-50 displayMedicine p-5 border border-white-light hover:drop-shadow-lg hover:border-none">
    <a href="<?php echo e(url('medicine-details/'.$value['id'].'/'.Str::slug($value['name']))); ?>">
        <img class="lg:h-52 lg:w-full" src="<?php echo e($value['fullImage']); ?>" alt="" />
    </a>
    <p class="text-slate-500 text-left font-medium text-lg text-black py-2 leading-5 font-fira-sans"><?php echo e($value['name']); ?></p>
    <div class="flex justify-between">
        <p class="font-fira-sans font-medium text-xl leading-6 text-primary text-left"><?php echo e($currency); ?><?php echo e($value['price_pr_strip']); ?></p>
        <div class="sessionCart<?php echo e($value['id']); ?>">
            <?php if(Session::get('cart') == null): ?>
            <a href="javascript:void(0);" onclick="addCart(<?php echo e($value['id']); ?>,'plus')"
                class="cart text-primary cursor-pointer"><i class="fa-solid fa-bag-shopping"></i></a>
            <?php else: ?>
            <?php if(in_array($value['id'], array_column(Session::get('cart'), 'id'))): ?>
            <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($cart['id'] == $value['id']): ?>
            <div class="flex flex-row h-10 w-full rounded-lg relative bg-transparent mt-1">
                <button  data-te-ripple-init data-te-ripple-color="light" id="minus<?php echo e($value['id']); ?>" onclick="addCart(<?php echo e($value['id']); ?>,`minus`)"
                    data-mdb-ripple-color="light" data-action="decrement"
                    class="border-l border-t border-b border-white-light text-black-600 hover:text-black-700 h-8 w-6 cursor-pointer">
                    <span class="m-auto text-2xl font-thin">−</span>
                </button>
                <input type="number" id="txtCart<?php echo e($value['id']); ?>" readonly
                    class="border-t border-b border-white-light outline-none focus:outline-none text-center w-10 font-semibold text-md hover:text-black focus:text-black md:text-basecursor-default flex items-center text-primary h-8"
                    name="custom-input-number" value="<?php echo e($cart['qty']); ?>">
                <button  data-te-ripple-init data-te-ripple-color="light" onclick="addCart(<?php echo e($value['id']); ?>,`plus`)" data-mdb-ripple-color="light"
                    data-action="increment"
                    class="border-r border-t border-b border-white-light text-black-600 hover:text-black-700 h-8 w-6 cursor-pointer">
                    <span class="m-auto text-2xl font-thin">+</span>
                </button>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <a href="javascript:void(0);" onclick="addCart(<?php echo e($value['id']); ?>,'plus')"
                class="cart text-primary cursor-pointer"><i class="fa-solid fa-bag-shopping"></i></a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH E:\xampp_new\htdocs\laravel\Doctro_admin_website_v5.0.0_06-03-2023_NewDesign\resources\views/website/display_medicine.blade.php ENDPATH**/ ?>