<?php $__env->startSection('content'); ?>
<div class="mt-20 border-b border-white-light ">
    <h1 class="font-fira-sans font-semibold text-5xl text-center leading-10"><?php echo e(__('Our Blogs ')); ?></h1>
    <div class="p-5">
        <p class="font-fira-sans font-normal text-lg text-center leading-5 text-gray"><?php echo e(__('Lorem ipsum dolor sit
            amet, consectetur adipiscing elit.')); ?></p>
    </div>
</div>


<div class="xsm:mx-5 xlg:mx-20 pb-6">
    <div class="">
        <div class="pt-10">
            <h1 class="text-center font-fira-sans text-black font-medium text-4xl"><?php echo e($blog->title); ?></h1>
            <p class="py-5 font-fira-sans font-medium text-base text-center leading-5 text-blue"><?php echo e($blog->blog_ref); ?>

                <span class="text-gray font-normal leading-5">• <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d M,Y')); ?></span>
            </p>
        </div>
    </div>
</div>

<div class="mb-10">
    <div class="flex justify-center mb-10">
        <img src="<?php echo e(asset($blog->fullImage)); ?>" class="w-full object-fill xxsm:h-[200px] xsm:h-[300px] sm:h-[400px] xxmd:h-[500px] lg:h-[700px]" alt="Logo">
    </div>

    <div class="xl:w-3/4 mx-auto">
        <div class="xxsm:mx-5 xl:mx-0 2xl:mx-0">
            <?php echo $blog->desc; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout',['activePage' => 'ourblogs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_new\htdocs\laravel\Doctro_admin_website_v5.0.0_06-03-2023_NewDesign\resources\views/website/our_blog_single.blade.php ENDPATH**/ ?>