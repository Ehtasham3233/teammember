<script>
    var msg = "<?php echo $status; ?>"
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    Toast.fire({
        icon: 'success',
        title: msg
    })
</script>
<?php /**PATH E:\xampp_new\htdocs\laravel\Doctro_admin_website_v5.0.0_06-03-2023_NewDesign\resources\views/superAdmin/auth/status.blade.php ENDPATH**/ ?>