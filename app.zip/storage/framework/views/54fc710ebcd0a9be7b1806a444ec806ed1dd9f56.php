

<?php $__env->startSection('content'); ?>

<div class="pt-14">
    <h1 class="font-fira-sans font-semibold text-5xl text-center leading-10 mb-5"><?php echo e(__('About Us ')); ?></h1>
    <div class="xsm:mx-20 xxsm:mx-5">
        <div class="mb-10">
            <?php echo $aboutUs; ?>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout',['activePage' => 'terms'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/b3m1b0l4/public_html/resources/views/website/about.blade.php ENDPATH**/ ?>