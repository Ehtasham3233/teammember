<?php echo clean($content); ?>

<?php /**PATH /home/b3m1b0l4/public_html/resources/views/send_mail.blade.php ENDPATH**/ ?>