
<?php $__env->startSection('title',__('Forgot Password')); ?>
<?php $__env->startSection('content'); ?>
<div class="xl:w-3/4 mx-auto">
    <div class="flex justify-between items-center pt-20 pb-20 gap-10 lg:flex-row xxsm:flex-col xxsm:mx-5 xl:mx-0 2xl:mx-0">
        <div class="bg-slate-100 justify-center items-center p-10 2xl:w-2/4 xxsm:w-full">
            <h1 class="font-fira-sans leading-10 font-medium text-3xl mb-10"><?php echo e(__('Talk to thousands of specialist doctors.')); ?></h1>
            <div>
                <img src="<?php echo e(asset('assets/image/login.png')); ?>" class="w-full h-3/5" alt="">
            </div>
        </div>
        <div class="2xl:w-2/4 xxsm:w-full">
            <h1 class="font-fira-sans leading-10 font-normal text-3xl"><?php echo e(__('Welcome Back,')); ?></h1>
            <h1 class="font-fira-sans leading-10 font-medium text-3xl"><?php echo e(__('Forgot Password For Patient Account')); ?></h1>
            <form action="<?php echo e(url('/user_forget_password')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="pt-5">
                    <label for="email" class="font-fira-sans text-black text-sm font-normal"><?php echo e(__('Email')); ?></label>
                    <input name="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-full text-sm font-fira-sans text-gray block p-2 z-20 border border-white-light" placeholder="Enter email" required type="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if(session('error')): ?>
                <div class="text-center">
                    <span class="custom_error text-red font-fira-sans font-normal text-base mt-1"><?php echo e(session('error')); ?></span>
                </div>
                <?php endif; ?>
                <div class="pt-10">
                    <button type="submit" class="font-fira-sans text-white bg-primary w-full text-sm font-normal py-3"><?php echo e(__('Send Email')); ?></button>
                    <h1 class="font-fira-sans font-medium text-sm leading-5 pt-4 text-center text-primary text-normal"><a href="<?php echo e(url('/patient-login')); ?>"><?php echo e(__('Remember Password ?')); ?> </a></h1>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout',['activePage' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/b3m1b0l4/public_html/resources/views/website/user/forgot_password.blade.php ENDPATH**/ ?>