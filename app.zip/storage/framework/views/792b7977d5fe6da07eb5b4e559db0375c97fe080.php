

<?php $__env->startSection('title',__('Add subscription')); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <?php echo $__env->make('layout.breadcrumb',[
        'title' => __('Add Subscription'),
        'url' => url('subscription'),
        'urlTitle' => __('Subscription'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <form action="<?php echo e(url('subscription')); ?>" method="post" class="myform">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label class="col-form-label"><?php echo e(__('Subscription plan name')); ?></label>
                    <input type="text" value="<?php echo e(old('name')); ?>" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label class="col-form-label"><?php echo e(__('Availabel Total appointments')); ?></label>
                    <input type="number" min="1" value="<?php echo e(old('total_appointment')); ?>" name="total_appointment" class="form-control <?php $__errorArgs = ['total_appointment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['total_appointment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <label class="col-form-label"><?php echo e(__('Subscription plan validity and price')); ?></label>
                <div class="registrations-info mt-3">
                    <div class="row form-row reg-cont">
                        <div class="col-12 col-md-5 form-group">
                            <label class="col-form-group"><?php echo e(__('Month')); ?></label>
                            <input type="number" min="1" name="month[]" required class="form-control">
                        </div>
                        <div class="col-12 col-md-5 form-group">
                            <label><?php echo e(__('price')); ?></label>
                            <input type="number" min="1" name="price[]" required class="form-control">
                        </div>
                    </div>
                </div>
                <div class="add-more">
                    <a href="javascript:void(0);" class="add-reg"><i class="fa fa-plus-circle"></i><?php echo e(__('Add More')); ?></a>
                </div>
                <div class="text-right">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </div>
        </form>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout_admin',['activePage' => 'subscription'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/b3m1b0l4/public_html/resources/views/superAdmin/subscription/create_subscription.blade.php ENDPATH**/ ?>