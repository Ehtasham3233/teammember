<!doctype HTML>
<html>

<head>
    <?php
    $setting = App\Models\Setting::first();
    ?>
    <title><?php echo e($setting->business_name); ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e($setting->favicon); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <input type="hidden" name="base_url" id="base_url" value="<?php echo e(url('/')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />

    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets_admin/css/select2.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />

    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.3/flowbite.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets_admin/css/datatables.min.css')); ?>" />
    <script type="text/javascript" src="<?php echo e(url('assets_admin/js/sweetalert2@10.js')); ?>"></script>

    <?php echo $__env->yieldContent('css'); ?>
    <style>
        :root {
            --site_color: <?php echo $setting->website_color;
                            ?>;
            --site_color_hover: <?php echo $setting->website_color . '70';
                                ?>;
        }
    </style>
</head>

<?php if(session()->has('direction') && session()->get('direction') == 'rtl'): ?>
<link rel="stylesheet" href="<?php echo e(asset('css/rtl.css')); ?>">

<body dir="rtl">
    <?php else: ?>

    <body>
        <?php endif; ?>
        <?php echo $__env->make('layout.partials.navbar_website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(auth()->check()): ?>    
    
            <?php if(auth()->user()->verify == 0): ?>
            <script>            
                var url =  window.location.origin+window.location.pathname;
                var to = url.lastIndexOf('/');
                to = to == -1 ? url.length : to;
                url2 = url.substring(0, to);
                var a = url2 + '/send_otp';
                console.log(a);
                if (window.location.origin + window.location.pathname != a)
                {
                    window.location.replace(a);
                }
            </script>
            <?php endif; ?>
        <?php endif; ?>
        <div class="main_content overflow-hidden">
                <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('assets_admin/js/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets_admin/js/select2.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.3/flowbite.js"></script>
        <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>
        <script src="<?php echo e(url('js/app.js')); ?>"></script>
        <?php echo $__env->yieldContent('js'); ?>
    </body>

</html><?php /**PATH E:\xampp_new\htdocs\laravel\Doctro_admin_website_v5.0.0_06-03-2023_NewDesign\resources\views/layout/mainlayout.blade.php ENDPATH**/ ?>