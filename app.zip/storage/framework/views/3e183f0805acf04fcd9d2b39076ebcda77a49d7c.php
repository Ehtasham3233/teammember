<?php echo clean($content); ?>

<?php /**PATH E:\xampp_new\htdocs\laravel\Doctro_admin_website_v5.0.0_06-03-2023_NewDesign\resources\views/send_mail.blade.php ENDPATH**/ ?>