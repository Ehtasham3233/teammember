{!! clean($content) !!}
